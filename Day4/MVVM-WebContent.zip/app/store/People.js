Ext.define('MVVM.store.People', {
    extend  : 'Ext.data.Store',

    requires : [
        'MVVM.model.Person'
    ],
    
    storeId : 'People',
    model   : 'MVVM.model.Person',
    
    data : [
        { 
            'name'  : 'Laxx',  
            'email' : 'laxx@zvarad.com',
            'phone' : '98864-37824' 
        },
        { 
            'name'  : 'Maxx',  
            'email' : 'maxx@zvarad.com',
            'phone' : '78299-02889'
        },
        { 
            'name'  : 'Bash', 
            'email' : 'bash@zvarad.com',
            'phone' : '92305-39977'
        },
        { 
            'name'  : 'Vans', 
            'email' : 'vans@zvarad.com',
            'phone' : '89152-67685'
        }
    ]
});