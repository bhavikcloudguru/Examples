Ext.define('MVVM.view.DetailViewModel', {
    extend: 'Ext.app.ViewModel',

    alias: 'viewmodel.detailform',
    
    data : {
        rec : null
    }
});