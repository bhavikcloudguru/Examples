
Ext.application({
	name				: 'MyApp',
	appFolder			: 'app',
	controllers			: [
		'MyApp.controller.main.Main','MyApp.controller.clients.Clients' 
	],
	autoCreateViewport	: true
});
