

Ext.define('MyApp.controller.categories.Categories',{
	extend      : 'Ext.app.Controller',

	init   : function(){
		var me = this;


	}
});