

Ext.define('MyApp.controller.invoices.Invoices',{
	extend      : 'Ext.app.Controller',

	init   : function(){
		var me = this;


	}
});