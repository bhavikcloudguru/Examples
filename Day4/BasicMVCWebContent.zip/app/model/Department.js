Ext.define('AM.model.Department', {
    extend: 'Ext.data.Model',
    fields: ['code', 'name', 'location']
});